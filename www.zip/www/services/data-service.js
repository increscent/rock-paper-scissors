angular.module('RPS.dataService', [])

.service('dataService', function () {
  this.initial_players = [];
  this.current_palyers = [];
  this.username = '';
});
